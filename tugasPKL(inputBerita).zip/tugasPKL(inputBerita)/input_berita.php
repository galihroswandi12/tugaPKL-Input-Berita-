<?php
include 'koneksi.php';

// proses input berita
if( isset($_POST['input']) ){
    $judul = addslashes(strip_tags($_POST['judul']));
    $kategori = $_POST['kategori'];
    $headline = addslashes(strip_tags($_POST['headline']));
    $isi_berita = addslashes(strip_tags($_POST['isi']));
    $pengirim = addslashes(strip_tags($_POST['pengirim']));
    
    // insert ke table 
    $query = "INSERT INTO tbl_berita 
        VALUES ('',
            '$kategori',
            '$judul',
            '$headline',
            '$isi_berita',
            '$pengirim',
            now())";
    
    $sql = mysqli_query($koneksi ,$query);
    if( $sql ){
        echo "<h2><font color=blue>Berita telah berhasil ditambahkan</font></h2>";
    }else{
        echo "<h2><font color=blue>Berita gagal ditambahkan</font></h2>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Input Berita</title>
    </head>
    <body>
        <a href="index.php">Beranda</a>
        <a href="arsip_berita.php">Arsip Berita</a>
        <a href="input_berita.php">Input Berita</a>
        <br><br>

        <form action="" method="POST">
            <table cellpadding="0" cellspacing="0" border="0" width="700">
                <tr>
                    <td colspan="2"><h2>Input Berita</h2></td>
                </tr>
                <tr>
                    <td width="200">Judul Berita</td>
                    <td>: <input type="text" name="judul" id="" size="30"></td>
                </tr>
                <tr>
                    <td>Kategori</td>
                    <td>:
                        <select name="kategori" id="">
                            <option value="-" selected>- Pilih Kategori -</option>
                            <?php 
                                $query = "SELECT id_kategori, nm_kategori FROM tbl_kategori ORDER BY nm_kategori ASC";

                                $sql = mysqli_query($koneksi, $query);
                                while($hasil = mysqli_fetch_assoc($sql)):
                            ?>
                                <option value="<?=$hasil['id_kategori']?>"><?=$hasil['nm_kategori']?></option>
                            <?php endwhile; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Headline Berita</td>
                    <td>: <textarea name="headline" id="" cols="50" rows="4"></textarea></td>
                </tr>
                <tr>
                    <td>Isi Berita</td>
                    <td>: <textarea name="isi" id="" cols="50" rows="10"></textarea></td>
                </tr>
                <tr>
                    <td>Pengirim</td>
                    <td>: <input type="text" name="pengirim" id="" size="20"></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;&nbsp;<input type="submit" value="Input Berita" name="input"> <input type="reset" value="cancel"></td>
                </tr>
            </table>
        </form>
    </body>
</html>