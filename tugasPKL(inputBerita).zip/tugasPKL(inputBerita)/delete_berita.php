<?php
include 'koneksi.php';
if( isset($_GET['id'])){
    $id_berita = $_GET['id'];
}else{
    die('Error. No Id Selected !');
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Delete Berita</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <a href="index.php">Halaman Depan</a>
        <a href="arsip_berita.php">Arsip Berita</a>
        <a href="input_berita.php">Input Berita</a>
        <br><br>

        <?php
            // proses delete berita
            if( !empty($id_berita) && $id_berita != ''){
                $query = "DELETE FROM tbl_berita WHERE id_berita = '$id_berita'";
                $sql = mysqli_query($koneksi, $query);

                if( $sql ){
                    echo "<h2><font color=blue>Berita Telah Berhasil Dihapus</font></h2>";
                }else{
                    echo "<h2><font color=red>Berita Gagal Dihapus</font></h2>";
                }

                echo "Klik <a href='arsip_berita.php'>di sini</a> untuk kembali ke arsi berita";
            }else {
                die('Access Denied');
            }
        ?>
    </body>
</html>